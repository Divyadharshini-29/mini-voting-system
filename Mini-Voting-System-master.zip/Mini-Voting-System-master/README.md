# Mini-Voting-System-Using-C-Language

    -> Allows us to set up a flexible and trustworthy voting system
    -> Applicable for large as well as small group of people e.g. a batch, a class.
    -> Keeps a record of  every voting process.

# How to use?
### You can fork or download the repo, Once you have both the files "MAIN.C" and "ELECTION.H", You just need to compile and run MAIN.C
#### ( It's too easy, isn't it? ☺)
##### For Admin Panel Use Username: "Admin" Password: "admiN"

# Below is the video to see demo of project
## Link: https://drive.google.com/file/d/17yFA8VC9chpWav8kXXIYQR4B55sf4W9b/view?usp=sharing

### Feel free to raise issues if you find some errors or want to clear your doubts...

#### #mini project #voting system #c project
